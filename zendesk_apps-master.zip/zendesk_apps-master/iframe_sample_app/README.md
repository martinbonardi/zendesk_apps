:warning: *Use of this software is subject to important terms and conditions as set forth in the License file* :warning:

# iFrame Sample App

This is the iFrame Sample App for the Zendesk App marketplace that is available at all app locations in the new Zendesk interface, including nav_bar, top_bar, ticket_sidebar, new_ticket_sidebar, and user_sidebar. See [Manifest](http://developer.zendesk.com/documentation/apps/manifest.html) for more details about locations.

This app aims to be a good start to learn how to iframe things of different sizes and methods.

### The following information is displayed:

* This app displays the [Wikipedia](http://www.wikipedia.com) when it activates in all locations.

Please submit bug reports to [Zendesk](https://support.zendesk.com/requests/new). Pull requests are welcome.


### Screenshot(s):
![App Screen Shot](http://f.cl.ly/items/312E193e0e0n0x0z0O20/iframe.gif)
