# Reusable Template Sample App

This very simple sample app shows you how to reuse templates in Zendesk apps. It is intended for demonstration purposes or for training purposes.

### The following information is displayed:

* A template that says hello, and another template that says goodbye. Both templates include a common template.
* The app.activated event.
* Click events.

Please submit bug reports to [Zendesk Support](support@zendesk.com). Pull requests are welcome.

### Screenshot(s):

![](https://cloud.githubusercontent.com/assets/5535625/4245137/522167c6-3a2f-11e4-9d44-5145511e78ab.png)
