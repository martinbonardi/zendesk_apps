# Hello World Sample App

This very simple sample app shows you the very basics of our Apps framework and how easy it is to build an App for Zendesk. It is intended for demonstration purposes or for training purposes.

### The following information is displayed:

* 1 template with the name of the current logged in Agent.
* The app.activated event.

Please submit bug reports to [Zendesk Support](support@zendesk.com). Pull requests are welcome.

### Screenshot(s):

![](http://f.cl.ly/items/1Z3q3a1n0N1f2o2p2k0U/Screen%20Shot%202014-03-25%20at%206.09.52%20PM.png)
