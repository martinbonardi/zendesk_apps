:warning: *Use of this software is subject to important terms and conditions as set forth in the License file* :warning:

# Top Bar Sample App

This Sample App illustrates how to use the notify.json App API and popover() on top bar location Apps.

### The following information is displayed:

* location: top bar
* resize popover
* pane.activated event

Please submit bug reports to [Zendesk](https://support.zendesk.com/requests/new). Pull requests are welcome.

### Screenshot(s):

![here](http://f.cl.ly/items/2V1z202e1k0c0d2s1d2v/top_bar_sample_app.gif).
