:warning: *Use of this software is subject to important terms and conditions as set forth in the License file* :warning:

# Requirements Sample App

This sample app shows to the developers how to add Apps requirements to their Apps. "Apps Requirements" are a neat feature that allows your App to install business rules, ticket fields, and all other resources that it might need to function properly.

This App will  add requirements as well as "reference" those requirements from within the App.

For an App that only creates requirements and nothing else please see [Requirements Only Sample App](./requirements_only_sample_app)

### The following information is displayed:

* Create Apps requirements

Please submit bug reports to [Zendesk Support](support@zendesk.com). Pull requests are welcome.

### Screenshot(s):

N/A
