:warning: *Use of this software is subject to important terms and conditions as set forth in the License file* :warning:

# Conditional Locations Sample App

This App is designed to teach App developers about Conditonal Locations.

Conditional Locations allow your app to dynamically hide and show itself on Zendesk.

Please submit bug reports to [Zendesk Support](support@zendesk.com). Pull requests are welcome.

### Screenshot(s):

![App Screen Shot](http://f.cl.ly/items/2C2J3K2J300i2z2q1C05/0413a2c8-e54e-11e3-899b-ffdc91a4d8b7.png)
