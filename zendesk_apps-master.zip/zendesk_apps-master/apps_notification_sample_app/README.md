:warning: *Use of this software is subject to important terms and conditions as set forth in the License file* :warning:

# Apps Notification Sample App

This Sample App demonstrates how to use Apps notifications in Zendesk.

### The following information is displayed:

* an App growl like notification
* a template letting you choose the time you want this notification to be on for

Please submit bug reports to [Zendesk](https://support.zendesk.com/requests/new). Pull requests are welcome.

### Screenshot(s):

![modal](http://f.cl.ly/items/0a2b3x103R0s0e3T3t01/Screen%20Shot%202014-09-23%20at%201.12.25%20PM.png)

![modal](http://f.cl.ly/items/3b2U31002s443t2m0o1c/Screen%20Shot%202014-09-23%20at%201.12.39%20PM.png)
